# Arduino-IR-Photodiode-Transmitter
This projects features an infrared-based communication line between two Arduino cards using a diode and a photodiode functioning as the output and input respectively, using simple communication principles expressed in the "UART" protocol
